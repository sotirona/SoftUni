﻿

namespace _04.OpinionPoll
{
    public class Person
    {
        private string name;
        private int age;

        public string Name { get;}
        public int Age { get; }

        public Person(string name, int age)
        {
            this.Name = name;
            this.Age = age;
        }
    }
}
