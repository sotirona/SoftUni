﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Persons
{
    public static void Main()
    {
     
    }
}

