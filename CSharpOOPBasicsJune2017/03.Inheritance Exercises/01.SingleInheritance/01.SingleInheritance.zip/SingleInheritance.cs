﻿using System;

public class SingleInheritance
{
    public static void Main()
    {
        var puppy = new Puppy();

        puppy.Eat();
        puppy.Bark();
        puppy.Weep();
    }
}

