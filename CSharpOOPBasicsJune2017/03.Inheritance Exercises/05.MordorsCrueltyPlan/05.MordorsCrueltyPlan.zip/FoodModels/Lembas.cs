﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class Lembas : Food
    {
        public Lembas()
            :base(3)
        {

        }
    }
}
