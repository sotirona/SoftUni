﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.MordorsCrueltyPlan.FoodModels
{
   public class Mushrooms: Food
    {
        public Mushrooms()
            :base(-10)
        {

        }
    }
}
