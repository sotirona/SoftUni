﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.MordorsCrueltyPlan.FoodModels
{
    public class OtherFood :Food
    {
        public OtherFood()
            : base(-1)
        {

        }

    }
}
