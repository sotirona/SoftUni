﻿using System;

public class Shapes
{
    public static void Main()
    {

    }
}

